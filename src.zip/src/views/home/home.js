// import React from 'react';
// import Navbar from '../navbar/navbar';
// import Category from '../category/categoty';
// import Posts from '../posts/post'
// import mobile from '../../images/mobile.jpeg'
// import SeeAd from '../seeAd/seeAd';
// import './home.css'
// import Sell from '../sell/sell';
// import seeAd from '../seeAd/seeAd';
// export default function home(prop) {
//   return <div>
  
//     {/* <Category /> */}

 

   
//    { prop.cond ? 
//   <SeeAd onClick={prop.SeeAd} post={prop.currentpost}/>

//     :
//     <div> {prop.stat? <Sell backbtn={prop.btn}/> :<Navbar checkstate={prop.stat} backbtnn={prop.btn} className="nav" onClickk={prop.SeeAd}  condition={prop.cond}  sellbtn={prop.btnsell} onclickpost={prop.onclickad} postss={prop.postobject} />}</div> }
     
//   </div>;
// }
