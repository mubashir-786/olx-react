import React from 'react';
import './sell.css'
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import backimg from '../../images/left-arrow.png'
import { addPosts } from '../../component/config/firebase';


export default function Sell(prop) {
  const [title, setTitle] = useState('')
  const [price, setPrice] = useState('')
  const [description, setDescription] = useState('')
  const [dropdown , setDropdown] = useState('')
  const navigate = useNavigate()
  const sellbtn = () => {
    addPosts(title, price, description, dropdown)
   }
  return <div>
    <div className='header'>
      <div className='innerheader' >
        <img src={backimg} alt="" onClick={() => navigate('/home')} className='backbtn' />
        <img src="https://www.olx.com.pk/assets/logo_noinline.1cdf230e49c0530ad4b8d43e37ecc4a4.svg" alt="" />

      </div>
    </div>

    <div>
      <h1 className='ad-heading' > POST YOUR AD</h1>
    </div>
    <div className='inputdiv' >
      <input type="text" placeholder='Title' className='titlee' onChange={(e)=> setTitle(e.target.value)} />
      <select name=" drop " id="" className='dropdown' onChange={(e)=>setDropdown(e.target.value)} >
        <option value="Accessoreis"> Accessories</option>
        <option value="Vehicles">Vehicles</option>
        <option value="Property">Property</option>
        <option value="Mobile">Mobiles</option>
      </select>



      <input type="text" placeholder='Discription' className='diss' onChange={(e)=> setDescription(e.target.value)} />

      <input type="text" placeholder='Price' className='pricee' onChange={(e)=> setPrice(e.target.value)} />

      <div className='file'>
        <label for="formFileLg" class="form-label"></label>
        <input class="form-control form-control-lg inputtt" id="formFileMultiple" type="file" multiple/>
      </div>
      <div className='btnn'>
             <button type="button" class="btn btn-secondary" onClick={sellbtn} >Submit Ad</button>
      </div>
 
    </div>

  </div>;
}
