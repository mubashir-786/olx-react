import React from 'react';
import backimg from '../../images/left-arrow.png'
import heartimg from '../../images/heart.png'
import './seeAd.css'
import post from '../posts/post';
import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom'
import { getAdDetail } from '../../component/config/firebase';


export default function SeeAd(prop) {
    const [post, setAds] = useState([])
  const pharam = useParams()
  console.log(pharam.adId)
   useEffect(async() => {
      const datas= await getAdDetail(pharam.adId)
       setAds(datas)
   },[])

 
  const navigate = useNavigate()
  if (post.length === 0) {
    return <div>Loading...</div>
  }
  return <div>

    {/* <button onClick={prop.onClick} > back </button>
      <h1>this is view ad page</h1> */}
    <div className='header'>
      <div className='innerheader' >
        <img src={backimg} alt="" className='backbtn' onClick={() => { navigate('/home') }} />
        <img src="https://www.olx.com.pk/assets/logo_noinline.1cdf230e49c0530ad4b8d43e37ecc4a4.svg" alt="" />
      </div>


    </div>
    <div className='container mt-5'>
      <div className='images'>
        <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
          <div class="carousel-inner">
            {/* {post.image.map((image, index) => {
              return <div class="carousel-item active" data-bs-interval="30000">
                <img src={image} class="d-block w-100 h-60" alt="..." />
                
              </div>
              
            }
            )} */}


          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
      </div>

      <div className='pricediv'>
        <h1 className='price-font' > Rs <span> {post.price}</span> </h1>
        <p className='titleview'> {post.title} </p>
        <img src={heartimg} alt="" className='heart-img' />
        <p className='locate' > {post.location}   </p>
        <p className='timee'>  {post.time}</p>

      </div>

      <div className='discription-div'>
        <h1 className='description-font' > Description </h1>

        <p className='descrip'>  {post.description}  </p>
      </div>

    </div>



  </div>;
}
