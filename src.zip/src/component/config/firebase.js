

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "firebase/auth";
import { getFirestore, collection, doc, addDoc, setDoc, getDocs,getDoc} from "firebase/firestore";

// Your web app's Firebase configuration

const firebaseConfig = {
    apiKey: "AIzaSyBMtdR8j5hgIx7yGTPwuXgA15L8wcwWGMY",
    authDomain: "olx-70c78.firebaseapp.com",
    projectId: "olx-70c78",
    storageBucket: "olx-70c78.appspot.com",
    messagingSenderId: "626075546718",
    appId: "1:626075546718:web:a739faaef591940f5db0cf"
  };
  

// Initialize Firebase
const app = initializeApp(firebaseConfig)
const auth = getAuth()
const db = getFirestore()


async function register(email, password, name) {
    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password)
        const uid = userCredential.user.uid
        await setDoc(doc(db, "users", uid), {
            name,
            email,
            password

        })
        alert('Successfully Registered and added in database')


    } catch (e) {
        alert(e.message)
    }

}


async function login(email, password) {
    try {
        const user = await signInWithEmailAndPassword(auth, email, password)
        alert('Successfully LoggedIn')
        

        return user
    } catch (e) {
        alert(e.message)
    }
}



async function addPosts(title, price, description, dropdown) {

    try {
        await addDoc(collection(db, "posts"), {
            title : title,
            price : price,
            description : description,
            dropdown : dropdown
        })
        alert('Successfully Added')
    } catch (e) {  
        alert(e.message)

    }
}
async function getAds() {
    const querySnapshot = await getDocs(collection(db, "posts"))
    const ads = []
    querySnapshot.forEach((doc) => {
      ads.push({ ...doc.data(), id: doc.id })
    })
    return ads
  }
   
 async function getAdDetail(idd) {
    

    const docRef = doc(db, "posts", idd);
    const docSnap = await getDoc(docRef);
    const data = docSnap.data()
    return data
  }

export {
    register,
    login,
    addPosts,
    getAds,
    getAdDetail

}





