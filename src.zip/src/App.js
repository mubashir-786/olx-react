import logo from './logo.svg';
import './App.css';
import Signup from './views/signup';
import Login from './views/login';
import { useState } from 'react'
import { register, login, addPosts } from './component/config/firebase'
import Home from './views/home/home';
import iphone from './images/mobile.jpeg'
import SeeAd from './views/seeAd/seeAd';
import Sell from './views/sell/sell';
import Navbar from './views/navbar/navbar'
import './views/home/home.css'
import Posts from './views/posts/post';
import './views/navbar/navbar.css'
import { FirebaseError } from 'firebase/app';
import Navigation from './component/config/router';
import { useNavigate } from 'react-router-dom'
import Router from './component/config/router'

function App() {
  const [email, setEmail] = useState('')
  const [pass, setPass] = useState('')
  const [name, setName] = useState('')
  const [page, setPage] = useState(true)
  const [seead, setstat] = useState(false)
  const [post, setpost] = useState()

 const [title, setTitle] = useState('')
  const [price, setPrice] = useState('')
  const [description, setDescription] = useState('')
  const [dropdown , setDropdown] = useState('')



  const onSign = () => {
    register(email, pass, name)
   // firebase.js to App.js conditional rendering

  }
  const onLogin = () => {
    login(email, pass)
  }
  // const navigate = useNavigate()
  
  const [t, f] = useState(false)

  const sellbtn = () => {
   addPosts(title, price, description, dropdown)
  }

  return (

    <div >
{/* 
{page?

<div> 


      {seead ?
        <SeeAd onClick={() => setstat(false)} post={postobj[post]} />

        :
        <div> {t ? <Sell backbtn={() => f(false)} 
              title={(e)=> setTitle(e.target.value)}
              dropdown = {(e)=>setDropdown(e.target.value)}
              price={(e)=> setPrice(e.target.value)}
              discription={(e)=> setDescription(e.target.value)}
              clicked = {sellbtn  }

        
        /> : <div>

          <Navbar className="nav" sellbtn={() => f(true)}

          />
          <div className='container'  >

            <h1 className='heading mt-5 ' >Fresh recommendations
            </h1>

            {postobj.map((item, index) => {
              return <Posts

                pic={item.thumbnail}
                title={item.title}
                price={item.price}
                time={item.time}

                postsee={() => {
                  setpost(index)
                }



                }
                onclickpost={() => setstat(true)} postss={postobj}


              />
            })}

          </div>

        </div>
        }</div>}
        </div>
: 
    <div className='container'>
      <Signup pp={(e) => setName(e.target.value)}
        email={e => setEmail(e.target.value)}
        passs={e => setPass(e.target.value)}
        onclick={onSign}
      />
    </div>
    } */}

    <Router />
  


    </div>











  );
}

export default App;
