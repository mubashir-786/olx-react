import React from 'react'
import backimg from '../../images/left-arrow.png'
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom'
export default function Profile() {
    const navigate = useNavigate()
    const pharam = useParams()
    console.log(pharam)
    return (
        <div>
            <div className='header'>
                <div className='innerheader' >
                    <img src={backimg} alt="" onClick={() => navigate('/home')} className='backbtn' />
                    <img src="https://www.olx.com.pk/assets/logo_noinline.1cdf230e49c0530ad4b8d43e37ecc4a4.svg" alt="" />

                </div>
            </div>
            <h1>Profile</h1>

        </div>
    )
}
