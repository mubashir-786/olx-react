import React from 'react'
import "./foter.css"
export default function Footer() {
    return (
        <div className='footerr' >
            <div className='container ccc' >
                <table>
                    <tr>
                        <td className='head-foot' >
                            POPULAR CATEGORIES
                        </td>
                        <td className='head-foot' >
                            TRENDING SEARCHES
                        </td>
                        <td className='head-foot' >
                            ABOUT US
                        </td>
                        <td className='head-foot' >
                            OLX
                        </td>

                    </tr>
                    <tr>
                        <td>  Cars</td>
                         <td>Bikes</td>
                         <td> About EMPG </td>
                         <td> Help </td>
                    </tr>
                    <tr>
                        <td> Flats for rent</td>
                         <td>Watches</td>
                         <td> Olx Blog</td>
                         <td> Terms </td>
                    </tr>
                    <tr>
                        <td> Mobile Phones</td>
                         <td>Books</td>
                         <td> Contact Us </td>
                         <td> Privacy Policy  </td>
                    </tr>
                    
                </table>
                
            </div>
            <div className='FooterEnd' >
                <div className='container'  >
                    <p className=' end-namee ' > Olx By Mubashir Raza </p>
                </div>
                    
                </div>
        </div>
    )
}
