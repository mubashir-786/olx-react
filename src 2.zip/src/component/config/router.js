import react from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Signup from "../../views/signup";
import Login from "../../views/login";
import Homee from '../../homee'
import Seead from "../../views/seeAd/seeAd";
import Sell from "../../views/sell/sell";
import Profile from "../../views/profile/profile";
import React from 'react'

export default function Navigation() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/signup" element={<Signup />} />
                <Route path="/" element={<Login />} />
                <Route path="/home" element={<Homee />} />
                <Route path="/sell" element={ <Sell/> } />
                <Route path="/postdetail" element={ <Seead/> } />
                <Route path="/seeAd/:adId" element={ <Seead/> } />
                <Route path="/profile" element={ <Profile/> } />


                
            </Routes>
        </BrowserRouter>
    )
}
